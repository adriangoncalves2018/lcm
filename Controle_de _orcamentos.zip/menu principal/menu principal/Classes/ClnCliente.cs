﻿using menu_principal.BD;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace menu_principal.Classes
{
   public class ClnCliente
    {
        string comando;
        ClnBancoDados objBancoDados = new ClnBancoDados();

        private string _registro, _nome, _cnpj, _inscricao, _fixo, _celular, _email,
            _cep, _rua, _uf, _bairro, _cidade, _numero, _complemento;

        public string Registro { get => _registro; set => _registro = value; }
        public string Nome { get => _nome; set => _nome = value; }
        public string Cnpj { get => _cnpj; set => _cnpj = value; }
        public string Inscricao { get => _inscricao; set => _inscricao = value; }
        public string Fixo { get => _fixo; set => _fixo = value; }
        public string Celular { get => _celular; set => _celular = value; }
        public string Email { get => _email; set => _email = value; }
        public string Cep { get => _cep; set => _cep = value; }
        public string Rua { get => _rua; set => _rua = value; }
        public string Uf { get => _uf; set => _uf = value; }
        public string Bairro { get => _bairro; set => _bairro = value; }
        public string Cidade { get => _cidade; set => _cidade = value; }
        public string Numero { get => _numero; set => _numero = value; }
        public string Complemento { get => _complemento; set => _complemento = value; }

        public SqlDataReader LocalizarCodigo(string registro)
        {
            comando = "select * from cliente where id_cliente ='" + registro + "'";
            return objBancoDados.RetornaLinha(comando);
        }

        public DataTable LocalizarPorNome(string strDescicao)
        {
            comando = "Select id_cliente as [CÓDIGO], NOME, fixo AS [TELEFONE], celular, email,cnpj from cliente Where nome like '%" + strDescicao + "%' and Ativo='1' order by id_cliente";
            return objBancoDados.RetornaTabela(comando);
        }
        public void Gravar()
        {
            comando = "INSERT INTO cliente ";
            comando += ("VALUES(");
            comando += ("'" + _nome + "',");
            comando += ("'" + _cnpj + "',");
            comando += ("'" + _inscricao + "',");
            comando += ("'" + _fixo + "',");
            comando += ("'" + _celular + "',");
            comando += ("'" + _email + "',");
            comando += ("'" + _rua + "',");
            comando += ("'" + _bairro + "',");
            comando += ("'" + _complemento + "',");
            comando += ("'" + _numero + "',");
            comando += ("'" + _cep + "',");
            comando += ("'" + _uf + "',");
            comando += ("'" + _cidade + "',");
            comando += ("'1'");
            comando += (")");
            objBancoDados.ExecutaComando(comando);
        }
        public void Alterar()
        {
            comando = ("UPDATE cliente ");
            comando += ("SET ");
            comando += ("nome = '" + _nome + "',");
            comando += ("cnpj = '" + _cnpj + "',");
            comando += ("inscricao = '" + _inscricao + "',");
            comando += ("fixo = '" + _fixo + "',");
            comando += ("celular = '" + _celular + "',");
            comando += ("email = '" + _email + "',");
            comando += ("rua = '" + _rua + "',");
            comando += ("bairro = '" + _bairro + "',");
            comando += ("complemento = '" + _complemento + "',");
            comando += ("numero = '" + _numero + "',");
            comando += ("cep = '" + _cep + "',");
            comando += ("uf = '" + _uf + "',");
            comando += ("cidade = '" + _cidade + "',");
            comando += ("Ativo = '1'");
            comando += ("WHERE ");
            comando += ("id_cliente = ' " + _registro + "'");
            objBancoDados.ExecutaComando(comando);
        }

        public void ExcluirLogicamente()
        {
            comando = ("delete from cliente ");
            comando += ("WHERE ");
            comando += ("id_cliente = ' " + _registro + "'");
            objBancoDados.ExecutaComando(comando);
        }
    }
}
