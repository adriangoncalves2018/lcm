﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using menu_principal.BD;

namespace menu_principal.Classes
{
    public class ClnOrcamento
    {
        string comando;
        ClnBancoDados ObjBancoDados = new ClnBancoDados();

        private string _nome_cliente, _valor, _cobrado, _data, _registro;

        public string Nome_cliente { get => _nome_cliente; set => _nome_cliente = value; }
        public string Valor { get => _valor; set => _valor = value; }
        public string Cobrado { get => _cobrado; set => _cobrado = value; }
        public string Data { get => _data; set => _data = value; }
        public string Registro { get => _registro; set => _registro = value; }

        public DataTable LocalizarPorNome(string strDescicao)
        {
            comando = "Select id_cliente AS [Cliente] , Nome, CNPJ AS [CNPJ/CPF] from cliente Where nome like '%" + strDescicao + "%' order by id_cliente";
            return ObjBancoDados.RetornaTabela(comando);
        }

            public DataTable RetornaPesquisa(string strDescricao)
            {
                // pesquisar por NomePaciente ou NomeDentista ou NomeServico
                comando = "select orcamento.id_orcamento, cliente.nome, orcamento.valorGasto, orcamento.valorCobrado, orcamento.data as [DATA] from cliente inner join orcamento on cliente.id_cliente = orcamento.id_cliente where cliente.nome like '%" + strDescricao + "%'";

                return ObjBancoDados.RetornaTabela(comando);
            }

        

        public void Gravar()
        {
            comando = "INSERT INTO orcamento ";
            comando += ("VALUES(");
            comando += ("'" + _nome_cliente + "',");
            comando += ("'" + _valor + "',");
            comando += ("'" + _cobrado + "',");
            comando +=  ( " convert(datetime, '" + _data + "', 103), ");
            comando += ("'1'");
            comando += (")");
            ObjBancoDados.ExecutaComando(comando);
        }

        public void Excluir()
        {
            comando = ("delete from orcamento ");
            comando += ("WHERE ");
            comando += ("id_orcamento = ' " + _registro + "'");
            ObjBancoDados.ExecutaComando(comando);
        }
    }
}
