﻿using menu_principal.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace menu_principal
{
    public partial class FrmCadCliente : Form
    {
      
        ClnUtil ObjUtil = new ClnUtil();
        ClnCliente objclnCliente = new ClnCliente();
        public FrmCadCliente()
        {
            InitializeComponent();
        }

        private void BtnGravar_Click(object sender, EventArgs e)
        {
            if ((txtNome.Text == "") || (maskedTextBoxTelCelular.Text == "")||
                 (txtEmail.Text == "") || (txtInscricao.Text == ""))
            {
                MessageBox.Show("Os campos com * são obrigatórios", "Item Novo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                objclnCliente.Nome = txtNome.Text;
                objclnCliente.Cnpj = maskedTextBoxCnpj.Text;
                objclnCliente.Inscricao = txtInscricao.Text;
                objclnCliente.Fixo = maskedTextBoxTelFixo.Text.Replace("-", "");
                objclnCliente.Celular = maskedTextBoxTelCelular.Text.Replace("-", ""); ;
                objclnCliente.Email = txtEmail.Text;
                objclnCliente.Cep = maskedTextBoxCep.Text.Replace("-", "");
                objclnCliente.Rua = txtRua.Text;
                objclnCliente.Bairro = txtBairro.Text;
                objclnCliente.Numero = txtNumerodaCasa.Text;
                objclnCliente.Uf = cboUF.Text;
                objclnCliente.Cidade = txtCidade.Text;
                objclnCliente.Complemento = txtComplemento.Text;

                if (txtRegistro.Text == "")
                {
                    objclnCliente.Gravar();
                    MessageBox.Show("Registo gravado com Sucesso", "Item Novo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else if (txtRegistro.Text != "")
                {
                    objclnCliente.Registro = txtRegistro.Text;
                    objclnCliente.Alterar();
                    MessageBox.Show("Registro Número " + txtRegistro.Text + ", Alterado com sucesso", "alteração", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                Close();
            }
        }

        private void MaskedTextBoxCep_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SqlDataReader drDados;
                string cep = maskedTextBoxCep.Text.Replace("-", "");
                drDados = ObjUtil.ProcuraCep(cep);
                if (drDados.Read())
                {
                    txtRua.Text = Convert.ToString(drDados["descricao"]);
                    cboUF.Text = Convert.ToString(drDados["UF"]);
                    txtBairro.Text = Convert.ToString(drDados["Bairro"]);
                    txtCidade.Text = Convert.ToString(drDados["cidade"]);
                    txtNumerodaCasa.Focus();
                }

                else
                {
                    MessageBox.Show("Cep não encontrado" + maskedTextBoxCep.Text, "Cep", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtRua.Text = "";
                    cboUF.Text = "";
                    cboUF.Text = "";
                    txtBairro.Text = "";
                    txtCidade.Text = "";

                    maskedTextBoxCep.Clear(); maskedTextBoxCep.Focus();
                    maskedTextBoxCep.Mask = "00000-999";
                    maskedTextBoxCep.SelectionStart = 0;
                }
            }
        }

        private void TxtEmail_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (ClnUtil.validarRegEx(txtEmail.Text))
                {
                    MessageBox.Show("E-MAIL INFORMADO É VÁLIDO! POR FAVOR, CONTINUE O CADASTRO!", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {

                    MessageBox.Show("E-MAIL INFORMADO É INVÁLIDO, TENTE NOVVAMENTE!", "OCORREU ERRO INESPERADO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void FrmCadCliente_Load(object sender, EventArgs e)
        {
            
            cboUF.DropDownStyle = ComboBoxStyle.DropDownList;
            PreencherUF();
            txtNome.Focus();
            if (txtRegistro.Text != "")
            {
                SqlDataReader ObjDrDados;
                ObjDrDados = objclnCliente.LocalizarCodigo(txtRegistro.Text);
                if (ObjDrDados.Read())
                {
                    txtNome.Text = ObjDrDados["nome"].ToString();
                    maskedTextBoxCnpj.Text = ObjDrDados["cnpj"].ToString();
                    txtInscricao.Text = ObjDrDados["inscricao"].ToString();
                    maskedTextBoxTelFixo.Text = ObjDrDados["fixo"].ToString();
                    maskedTextBoxTelCelular.Text = ObjDrDados["celular"].ToString();
                    txtEmail.Text = ObjDrDados["email"].ToString();
                    txtRua.Text = ObjDrDados["rua"].ToString();
                    txtBairro.Text = ObjDrDados["bairro"].ToString();
                    txtComplemento.Text = ObjDrDados["complemento"].ToString();
                    txtNumerodaCasa.Text = ObjDrDados["numero"].ToString();
                    maskedTextBoxCep.Text = ObjDrDados["cep"].ToString();
                    cboUF.Text = ObjDrDados["uf"].ToString();
                    txtCidade.Text = ObjDrDados["cidade"].ToString();
                }
                txtNome.Focus();
            }
        }
        public void PreencherUF()
        {
            cboUF.DataSource = ObjUtil.PreencherUF();
            cboUF.ValueMember = "UF";
            cboUF.DisplayMember = "UF";
            cboUF.SelectedIndex = 23;
        }

        private void MaskedTextBoxCnpj_KeyDown(object sender, KeyEventArgs e)
        {
            ClnUtil obj = new ClnUtil();
            if (e.KeyCode == Keys.Enter)
            {

                if (ClnUtil.CpfCnpjUtils.IsValid(maskedTextBoxCnpj.Text) == false)
                {
                    MessageBox.Show("CPF ou CNPJ INVÁLIDO DIGITE NOVAMENTE", "Erro Inesperado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("CPF ou CNPJ INFORMADO É VÁLIDO! POR FAVOR, CONTINUE O CADASTRO!", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void FrmCadCliente_Validated(object sender, EventArgs e)
        {

        }
    }
}

