﻿using menu_principal.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace menu_principal.Telas
{
    public partial class Orcamento : Form
    {
        public static string Temp2;
        
        public Orcamento()
        {
            InitializeComponent();
        }


        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            FrmPesquisarCliente abrir = new FrmPesquisarCliente();
            ClnUtil.Temp = txtCliente.Text;

            abrir.ShowDialog();

            txtCliente.Text = ClnUtil.Temp;

        }

        private void Button2_Click(object sender, EventArgs e)
        {

        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            string formato = "dd/MM/yyyy";
            DateTime dataInicio = DateTime.ParseExact(txtdata.Text, formato, System.Globalization.CultureInfo.CurrentCulture);
            ClnOrcamento ObjOrcamento = new ClnOrcamento();
            

            if (txtCliente.Text == "" || txtCobrado.Text == "" || txtdata.Text == "" ||
                txtValor.Text == "" || txtCobrado.Text == "" )
            {
                MessageBox.Show("TODOS OS CAMPOS SÃO OBRIGATÓRIOS ", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if(DateTime.Today <= dataInicio)
            { 
            
            
              
                ObjOrcamento.Nome_cliente = Temp2;
                ObjOrcamento.Valor = txtValor.Text;

                ObjOrcamento.Cobrado = txtCobrado.Text;
             
                string data = txtdata.Text;
                ObjOrcamento.Data = data;
                ObjOrcamento.Gravar();
                MessageBox.Show("Registo gravado com Sucesso", "Item Novo", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("Data não corresponde ", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }
    }
}
