﻿using menu_principal.Telas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace menu_principal
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void CIENTEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCadCliente objCli = new FrmCadCliente();
            objCli.ShowDialog();
        }

        private void ClienteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FrmCliente obj = new FrmCliente();
            obj.ShowDialog();
        }

        private void SAIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PESQUISAPORAGENDAMENTOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Orcamento abrir = new Orcamento();
            abrir.ShowDialog();
        }

        private void LucrosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OrcamentoConsulta abrir = new OrcamentoConsulta();
            abrir.ShowDialog();
        }
    }
}
