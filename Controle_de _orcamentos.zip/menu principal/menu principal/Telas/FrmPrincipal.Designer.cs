﻿namespace menu_principal
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrincipal));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuCad = new System.Windows.Forms.ToolStripMenuItem();
            this.CIENTEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sAIRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAgendamento = new System.Windows.Forms.ToolStripMenuItem();
            this.pESQUISAPORAGENDAMENTOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuConsultas = new System.Windows.Forms.ToolStripMenuItem();
            this.clienteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lucrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuCad,
            this.menuAgendamento,
            this.menuConsultas});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip1.Size = new System.Drawing.Size(876, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuCad
            // 
            this.menuCad.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CIENTEToolStripMenuItem,
            this.sAIRToolStripMenuItem});
            this.menuCad.Name = "menuCad";
            this.menuCad.Size = new System.Drawing.Size(86, 20);
            this.menuCad.Text = "&CADASTRAR";
            // 
            // CIENTEToolStripMenuItem
            // 
            this.CIENTEToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("CIENTEToolStripMenuItem.Image")));
            this.CIENTEToolStripMenuItem.Name = "CIENTEToolStripMenuItem";
            this.CIENTEToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.CIENTEToolStripMenuItem.Text = "CLIENTE";
            this.CIENTEToolStripMenuItem.Click += new System.EventHandler(this.CIENTEToolStripMenuItem_Click);
            // 
            // sAIRToolStripMenuItem
            // 
            this.sAIRToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sAIRToolStripMenuItem.Image")));
            this.sAIRToolStripMenuItem.Name = "sAIRToolStripMenuItem";
            this.sAIRToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.sAIRToolStripMenuItem.Text = "SAIR";
            this.sAIRToolStripMenuItem.Click += new System.EventHandler(this.SAIRToolStripMenuItem_Click);
            // 
            // menuAgendamento
            // 
            this.menuAgendamento.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pESQUISAPORAGENDAMENTOSToolStripMenuItem,
            this.lucrosToolStripMenuItem});
            this.menuAgendamento.Name = "menuAgendamento";
            this.menuAgendamento.Size = new System.Drawing.Size(92, 20);
            this.menuAgendamento.Text = "&ORÇAMENTO";
            // 
            // pESQUISAPORAGENDAMENTOSToolStripMenuItem
            // 
            this.pESQUISAPORAGENDAMENTOSToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pESQUISAPORAGENDAMENTOSToolStripMenuItem.Image")));
            this.pESQUISAPORAGENDAMENTOSToolStripMenuItem.Name = "pESQUISAPORAGENDAMENTOSToolStripMenuItem";
            this.pESQUISAPORAGENDAMENTOSToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.pESQUISAPORAGENDAMENTOSToolStripMenuItem.Text = "Orçamento";
            this.pESQUISAPORAGENDAMENTOSToolStripMenuItem.Click += new System.EventHandler(this.PESQUISAPORAGENDAMENTOSToolStripMenuItem_Click);
            // 
            // menuConsultas
            // 
            this.menuConsultas.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clienteToolStripMenuItem1});
            this.menuConsultas.Name = "menuConsultas";
            this.menuConsultas.Size = new System.Drawing.Size(84, 20);
            this.menuConsultas.Text = "&CONSULTAS";
            // 
            // clienteToolStripMenuItem1
            // 
            this.clienteToolStripMenuItem1.Name = "clienteToolStripMenuItem1";
            this.clienteToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.clienteToolStripMenuItem1.Text = "Cliente";
            this.clienteToolStripMenuItem1.Click += new System.EventHandler(this.ClienteToolStripMenuItem1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::menu_principal.Properties.Resources.logo24;
            this.pictureBox1.Location = new System.Drawing.Point(148, 51);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(659, 376);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // lucrosToolStripMenuItem
            // 
            this.lucrosToolStripMenuItem.Name = "lucrosToolStripMenuItem";
            this.lucrosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.lucrosToolStripMenuItem.Text = "Lucros";
            this.lucrosToolStripMenuItem.Click += new System.EventHandler(this.LucrosToolStripMenuItem_Click);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(876, 452);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "FrmPrincipal";
            this.Text = "FrmPrincipal";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.MenuStrip menuStrip1;
        public System.Windows.Forms.ToolStripMenuItem menuCad;
        public System.Windows.Forms.ToolStripMenuItem CIENTEToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem sAIRToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem menuAgendamento;
        public System.Windows.Forms.ToolStripMenuItem pESQUISAPORAGENDAMENTOSToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem menuConsultas;
        public System.Windows.Forms.ToolStripMenuItem clienteToolStripMenuItem1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem lucrosToolStripMenuItem;
    }
}