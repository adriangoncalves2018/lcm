﻿using menu_principal.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace menu_principal.Telas
{
    public partial class FrmPesquisarCliente : Form
    {
        public FrmPesquisarCliente()
        {
            InitializeComponent();
        }

        public void CarregaDataGrid()
        {
            //frmAgenda cad = new frmAgenda();
            ClnOrcamento ObjOrc = new ClnOrcamento();
            dgv.DataSource = ObjOrc.LocalizarPorNome(ClnUtil.Temp);
        }

        private void FrmPesquisarCliente_Load(object sender, EventArgs e)
        {
            CarregaDataGrid();
        }


        private void BtnPesquisar_Click(object sender, EventArgs e)
        {
            CarregaDataGrid();
        }

        private void Dgv_DoubleClick_1(object sender, EventArgs e)
        {

            ClnUtil.Temp = dgv.CurrentRow.Cells[1].Value.ToString();
            Orcamento.Temp2 = dgv.CurrentRow.Cells[0].Value.ToString();
            Close();
        }

        private void Dgv_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Dgv_DoubleClick_1(sender, e);
            }
        }
    }

}
