﻿using menu_principal.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace menu_principal.Telas
{
    public partial class FrmCliente : Form
    {
        ClnCliente objCliente = new ClnCliente();
        public FrmCliente()
        {
            InitializeComponent();
        }

        private void BtnPesquisa_Click(object sender, EventArgs e)
        {
            CarregaDataGrid();
        }
        public void CarregaDataGrid()
        {
            dgv.DataSource = objCliente.LocalizarPorNome(txtPesquisa.Text);
            dgv.Columns[0].HeaderText = ("CÓDIGO");

            dgv.AutoResizeColumns();

            if (dgv.RowCount == 0)
            {
                btnConsulta.Enabled = false;
                btnEdita.Enabled = false;
                btnExcluir.Enabled = false;
                MessageBox.Show("NÃO FORAM ENCONTRADOS DADOS COM A INFORMAÇÃO " + txtPesquisa.Text, "Verificar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dgv.DataSource = null;
                txtPesquisa.Text = "";
                txtPesquisa.Focus();
            }
            else
            {
                btnConsulta.Enabled = true;
                btnEdita.Enabled = true;
                btnExcluir.Enabled = true;
            }
        }

        private void FrmCliente_Load(object sender, EventArgs e)
        {
            btnConsulta.Enabled = false;
            btnEdita.Enabled = false;
            btnExcluir.Enabled = false;
            dgv.RowHeadersVisible = false;
        }

        private void BtnGravar_Click(object sender, EventArgs e)
        {
            FrmCadCliente ObjCadastroCliente = new FrmCadCliente();

            ObjCadastroCliente.Text = ">>> NOVO CADASTRO <<<";
            ObjCadastroCliente.txtRegistro.Enabled = false;
            ObjCadastroCliente.ShowDialog();
            CarregaDataGrid();
        }

        private void BtnConsulta_Click(object sender, EventArgs e)
        {
            FrmCadCliente ObjCadastroCliente = new FrmCadCliente();
            ObjCadastroCliente.Text = ">>> CONSULTAR <<<";
            ObjCadastroCliente.btnGravar.Visible = false;
            ObjCadastroCliente.txtNome.Enabled = false;
            ObjCadastroCliente.maskedTextBoxCnpj.Enabled = false;
            ObjCadastroCliente.txtInscricao.Enabled = false;
            ObjCadastroCliente.maskedTextBoxTelFixo.Enabled = false;
            ObjCadastroCliente.maskedTextBoxTelCelular.Enabled = false;
            ObjCadastroCliente.txtEmail.Enabled = false;
            ObjCadastroCliente.maskedTextBoxCep.Enabled = false;
            ObjCadastroCliente.txtRua.Enabled = false;
            ObjCadastroCliente.cboUF.Enabled = false;
            ObjCadastroCliente.txtBairro.Enabled = false;
            ObjCadastroCliente.txtCidade.Enabled = false;
            ObjCadastroCliente.txtNumerodaCasa.Enabled = false;
            ObjCadastroCliente.txtComplemento.Enabled = false;

            ObjCadastroCliente.cboUF.DropDownStyle = ComboBoxStyle.DropDownList;

            ObjCadastroCliente.txtRegistro.Text = Convert.ToString(dgv.CurrentRow.Cells[0].Value);

            ObjCadastroCliente.ShowDialog();
            CarregaDataGrid();
        }

        private void BtnEdita_Click(object sender, EventArgs e)
        {
            FrmCadCliente ObjCadastroCliente = new FrmCadCliente();
            ObjCadastroCliente.Text = ">>> ALTERAR CADASTRO DO CLIENTE <<<";
            ObjCadastroCliente.txtRegistro.Enabled = false;
            ObjCadastroCliente.btnGravar.Text = "&ALTERAR";
            ObjCadastroCliente.txtRegistro.Text = Convert.ToString(dgv.CurrentRow.Cells[0].Value);
            ObjCadastroCliente.txtNome.Focus();
            ObjCadastroCliente.ShowDialog();
            CarregaDataGrid();
        }

        private void BtnExcluir_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Deseja excluir o Cliente: " + Convert.ToString(dgv.CurrentRow.Cells[0].Value + "?"),
                "E X C L U S Ã O", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (DialogResult.Yes == resultado)
            {
                objCliente.Registro = dgv.CurrentRow.Cells[0].Value.ToString();
                objCliente.ExcluirLogicamente();
                MessageBox.Show("CLIENTE Excluido com Sucesso", "E X C L U S Ã O", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Operação cancelada ", "cancelamento E X C L U S Ã O", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            CarregaDataGrid();
        }
    }
}
