﻿using menu_principal.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace menu_principal.Telas
{
    public partial class OrcamentoConsulta : Form
    {
        ClnOrcamento ObjOrcamento = new ClnOrcamento();
        public OrcamentoConsulta()
        {
            InitializeComponent();
        }

        private void BtnPesquisar_Click(object sender, EventArgs e)
        {
            CarregaDataGrid();
        }

        private void OrcamentoConsulta_Load(object sender, EventArgs e)
        {
            btnCalcularGasto.Enabled = false;
            btnCalcularLucro.Enabled = false;
            btnExcluir.Enabled = false;
            btnLimpar.Enabled = false;
        }
        public void CarregaDataGrid()
        {
            dgv.DataSource = ObjOrcamento.RetornaPesquisa(txtPesquisar.Text);

            dgv.AutoResizeColumns();
            dgv.Columns[0].HeaderText = "CÓDIGO";
            dgv.Columns[1].HeaderText = "NOME DO CLIENTE";
            dgv.Columns[2].HeaderText = "VALORES GASTOS";
            dgv.Columns[3].HeaderText = "VALORES DOS LUCROS ";

            if (dgv.RowCount == 0)
            {
                btnCalcularGasto.Enabled = false;
                btnCalcularLucro.Enabled = false;
                MessageBox.Show("NÃO FORAM ENCONTRADOS DADOS COM A INFORMAÇÃO " + txtPesquisar.Text, "Verificar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dgv.DataSource = null;
                txtPesquisar.Text = "";
                txtPesquisar.Focus();
            }
            else
            {
                btnCalcularGasto.Enabled = true;
                btnCalcularLucro.Enabled = true;
                btnExcluir.Enabled = true;
                btnLimpar.Enabled = true;
            }
        }

        private void BtnCalcularGasto_Click(object sender, EventArgs e)
        {
            SomarGasto();
        }
        public void SomarGasto()
        {
             double total = 0;
             //DataGridView linha;
            foreach(DataGridViewRow row in dgv.Rows)
            {
                total += Convert.ToDouble(row.Cells[2].Value);
            }
            MessageBox.Show("Valor é R$: "+ total);
        }

        private void BtnCalcularLucro_Click(object sender, EventArgs e)
        {
            SomarLucro();
        }
        public void SomarLucro()
        {

            double total = 0;
            foreach (DataGridViewRow row in dgv.Rows)
            {
                total += Convert.ToDouble(row.Cells[3].Value);
            }
            MessageBox.Show("Valor é R$: " + total);
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            dgv.DataSource = null;
        }

        private void BtnExcluir_Click(object sender, EventArgs e)
        { 

            DialogResult resultado = MessageBox.Show("Deseja excluir o Cliente: " + Convert.ToString(dgv.CurrentRow.Cells[0].Value + "?"),
                "EXCLUSÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (DialogResult.Yes == resultado)
            {
                ObjOrcamento.Registro = dgv.CurrentRow.Cells[0].Value.ToString();
                ObjOrcamento.Excluir();
                MessageBox.Show("Registro Excluido com Sucesso", "EXCLUSÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Operação cancelada ", "cancelamento EXCLUSÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            CarregaDataGrid();
        }

        private void Dgv_KeyDown(object sender, KeyEventArgs e)
        {
         
        }

        private void BtnExcluir_KeyDown(object sender, KeyEventArgs e)
        {
            
        }
    }
}
